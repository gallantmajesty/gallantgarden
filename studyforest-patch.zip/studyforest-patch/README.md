# StudyForest — Performance + Inventory Patch

## What's in this patch

```
src/
├── three/library/
│   ├── RemotePlayers.tsx       ← PERF FIX #1 (root cause of 1-10 FPS)
│   └── LibraryScene.tsx        ← PERF FIX #2 + comprehensive PerfLogger
├── avatar/
│   ├── CharacterAvatar.tsx     ← PERF FIX #3 (LOD prop wired through)
│   └── config.ts               ← v4 avatar config (4 new cosmetic slots)
├── marketplace/
│   ├── types.ts                ← all inventory/equipment/rarity types
│   └── catalog.ts              ← 80+ item catalog (shirts→legendary wings)
├── store/
│   ├── inventory.ts            ← persistent inventory (Zustand + InsForge)
│   └── equipment.ts            ← equipment slots + presets (Zustand)
├── lib/
│   └── inventorySync.ts        ← auth lifecycle → inventory auto-load
├── components/marketplace/
│   ├── MarketplacePanel.tsx/css ← full marketplace UI (tabs, search, filter)
│   ├── ItemCard.tsx/css         ← virtualized item card
│   ├── EquipmentDresser.tsx/css ← 8-slot wardrobe UI
│   └── PresetManager.tsx/css    ← outfit presets (Casual / Study / Fantasy)
├── screens/
│   └── Marketplace.tsx/css      ← full-page / overlay screen wrapper
└── migrations/
    └── 004_inventory.sql        ← Supabase DB migration
```

---

## How to apply

### 1. Copy files into your project

Copy every file from `src/` into your project's `src/` folder,
**replacing** the existing files where they already exist.

```
# From this zip folder:
cp -r src/* /path/to/studyforest/src/
```

New folders that will be created:
- `src/marketplace/`
- `src/components/marketplace/`
- `src/migrations/`

### 2. Run the database migration

Open your **Supabase SQL Editor** and run:

```sql
-- paste the full contents of src/migrations/004_inventory.sql
```

This creates three tables (`user_inventory`, `user_equipped`, `user_presets`)
with RLS, indexes, and helper functions.

### 3. Wire up inventory sync (one line in your auth provider)

In your `AuthProvider` or app entry point (`main.tsx` / `App.tsx`), add:

```ts
import { initInventorySync } from './lib/inventorySync'

// Call once at startup — before any auth state is read
initInventorySync()
```

This automatically:
- Loads inventory + equipment from the server on sign-in
- Grants starter items to brand-new accounts
- Clears local state on sign-out

### 4. Open the Marketplace from anywhere

As a **full-page route** (add to your router):
```tsx
import { Marketplace } from './screens/Marketplace'

<Route path="/marketplace" element={<Marketplace />} />
```

As an **overlay** over the 3D realm:
```tsx
import { Marketplace } from './screens/Marketplace'

{showMarketplace && (
  <Marketplace onClose={() => setShowMarketplace(false)} />
)}
```

### 5. Equip items in your avatar pipeline

```ts
import { useEquipment } from './store/equipment'
import type { AvatarConfig } from './avatar/config'

function MyAvatar({ baseConfig }: { baseConfig: AvatarConfig }) {
  // avatarConfig merges equipped items on top of the base config
  const config = useEquipment((s) => s.avatarConfig(baseConfig))
  return <CharacterAvatar config={config} />
}
```

---

## Performance fixes explained

### Fix 1 — Avatar LOD (RemotePlayers.tsx) ★ ROOT CAUSE

**Before:** Every remote avatar was hard-coded to `lod='near'` — meaning
20+ players each updated ALL bones EVERY frame, collapsing the CPU.

**After:** Each avatar's LOD tier is computed from camera distance every frame:
| Distance | LOD tier | Bone updates |
|----------|----------|--------------|
| 0–12 m   | `near`   | Every frame  |
| 12–28 m  | `far`    | Every 3rd frame |
| 28 m+    | `cull`   | None — frozen pose |

**Expected FPS gain: 3–10× on scenes with 10+ players.**

### Fix 2 — DPR floor (LibraryScene.tsx)

**Before:** `dprFloor = 0.85` → PerformanceMonitor had 0–0.15 DPR headroom
= essentially useless on weak integrated GPUs.

**After:** `dprFloor = 0.6` → Governor can now halve fill-rate cost when needed.
On weak GPUs this alone can rescue 15–25 FPS.

### Fix 3 — Warm-up gate (LibraryScene.tsx)

**Before:** 8 s gate → PerformanceMonitor was blind for too long.
**After:** 5 s → covers shader compile + Suspense waterfall without excess.

### Fix 4 — PerfLogger (LibraryScene.tsx)

Open browser DevTools Console after entering the library.
Every 2 s (first 15 s) then every 10 s you'll see a full report:

```
[FocusLily perf] 58.2 fps | draws:47 tris:112k | progs:18 geo:31 tex:44
  | meshes:189 lights:3(pt:2 dir:1 spot:0) | shadowCasters:8
  ► ✓ No urgent bottleneck
```

If something is wrong you'll see ranked bottleneck messages like:
```
  ► ⚠ LOW FPS 12.4
  ► HIGH draw calls 387 → instance/merge static props
  ► MANY shadow casters 62 → castShadow=false on static props
```

---

## Inventory system

- Every owned item is stored in `user_inventory` (never deleted unless admin revoke)
- Persists across logout/login — synced to Supabase on every acquisition
- `localStorage` cache → instant UI on startup, server sync in background
- O(1) `owns(itemId)` lookup via Map — handles thousands of items
- Only **equipped** slots are synced during gameplay (8 item IDs max)
- Full inventory is fetched only when the Marketplace screen opens

---

## Catalog — 80+ items across 6 categories

| Category | Items |
|----------|-------|
| Clothing | Shirts, Hoodies, Jackets, Pants, Shorts, Skirts, Dresses, Shoes, Socks |
| Hair | Short, Long, Curly, Ponytails, Fantasy (ombre, sakura) |
| Accessories | Glasses, Hats, Caps, Headphones, Masks, Scarves, Backpacks |
| Special Effects | Wings (butterfly/angelic/arcane), Auras, Particles, Trails, Glows |
| Study Props | Floating Tome, Pencil Behind Ear, Notebook, Graduation Cap, Study Bag |

Rarities: Common → Uncommon → Rare → Epic → **Legendary**

Free starter items are granted automatically at signup.

---

## Equipment slots (v4 AvatarConfig)

| Slot | Items |
|------|-------|
| `hair` | All hair styles |
| `top` | Shirts, Hoodies, Jackets |
| `bottom` | Pants, Shorts, Skirts, Dresses |
| `shoes` | Shoes, Socks |
| `face_accessory` | Glasses, Masks, Scarves |
| `head_accessory` | Hats, Caps, Headphones, Graduation Cap |
| `back_accessory` | Backpacks, Wings, Study Props |
| `effect` | Auras, Particles, Trails, Glows |

Old v3 saves are automatically migrated by `migrateAvatarConfig()`.
