/**
 * Inventory sync — ties authentication lifecycle to inventory + equipment loading.
 *
 * Call initInventorySync() once at app startup (e.g. inside AuthProvider).
 * It subscribes to InsForge auth state changes and:
 *   • On sign-in:  loads inventory + equipment from server, bootstraps starter kit for new accounts
 *   • On sign-out: clears all local state so stale data can't leak between sessions
 *
 * This is intentionally the ONLY place that triggers loadFromServer/clear so
 * there is exactly one source of truth for the lifecycle handshake.
 */

import { insforge } from './insforge'
import { useInventory } from '../store/inventory'
import { useEquipment } from '../store/equipment'

let _initialised = false

export function initInventorySync() {
  if (_initialised) return
  _initialised = true

  insforge.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_IN' && session?.user) {
      const userId = session.user.id

      // Load in parallel — inventory and equipment are independent queries
      await Promise.all([
        useInventory.getState().loadFromServer(userId),
        useEquipment.getState().loadFromServer(userId),
      ])

      // Bootstrap starter kit for brand-new accounts (idempotent)
      await useInventory.getState().bootstrapStarterKit(userId)

    } else if (event === 'SIGNED_OUT') {
      useInventory.getState().clear()
      useEquipment.getState().clear()
    }
  })
}
