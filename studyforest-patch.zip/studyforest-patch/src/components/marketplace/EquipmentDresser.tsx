import { useState } from 'react'
import { useEquipment } from '../../store/equipment'
import { useInventory } from '../../store/inventory'
import { getCatalogItem } from '../../marketplace/catalog'
import { RARITY_COLOR, RARITY_LABEL, type EquipSlot } from '../../marketplace/types'
import './EquipmentDresser.css'

const SLOTS: { slot: EquipSlot; label: string; icon: string }[] = [
  { slot: 'hair',           label: 'Hair',            icon: '💇' },
  { slot: 'top',            label: 'Top',             icon: '👕' },
  { slot: 'bottom',         label: 'Bottom',          icon: '👖' },
  { slot: 'shoes',          label: 'Shoes',           icon: '👟' },
  { slot: 'face_accessory', label: 'Face Accessory',  icon: '🕶️' },
  { slot: 'head_accessory', label: 'Head Accessory',  icon: '🎩' },
  { slot: 'back_accessory', label: 'Back / Wings',    icon: '🎒' },
  { slot: 'effect',         label: 'Effect',          icon: '✨' },
]

/**
 * EquipmentDresser — shows all 8 equipment slots at once with their currently
 * equipped item. Clicking a slot opens a slot-filtered item picker from the
 * user's owned inventory so they can swap without visiting the shop.
 */
export function EquipmentDresser() {
  const { equipped, unequip, equip } = useEquipment()
  const { owns, ownedList }          = useInventory()
  const [activeSlot, setActiveSlot]  = useState<EquipSlot | null>(null)

  const slotItems = activeSlot
    ? ownedList().filter((entry) => {
        const item = getCatalogItem(entry.itemId)
        return item?.slot === activeSlot
      })
    : []

  return (
    <div className="ed-root">
      <h3 className="ed-title">⚡ Wardrobe</h3>
      <p className="ed-subtitle">Click a slot to swap from your owned items.</p>

      <div className="ed-slots">
        {SLOTS.map(({ slot, label, icon }) => {
          const equippedId = equipped[slot]
          const item       = equippedId ? getCatalogItem(equippedId) : null
          const isActive   = activeSlot === slot

          return (
            <button
              key={slot}
              className={['ed-slot', isActive ? 'ed-slot-active' : '', item ? 'ed-slot-filled' : ''].filter(Boolean).join(' ')}
              onClick={() => setActiveSlot(isActive ? null : slot)}
              aria-label={`${label} slot${item ? `: ${item.name}` : ' — empty'}`}
            >
              <span className="ed-slot-icon">{icon}</span>
              <span className="ed-slot-label">{label}</span>
              {item ? (
                <div className="ed-slot-item">
                  <img
                    src={item.thumbnail}
                    alt={item.name}
                    loading="lazy"
                    onError={(e) => { (e.target as HTMLImageElement).src = '/marketplace/thumbnails/placeholder.webp' }}
                  />
                  <span
                    className="ed-slot-rarity-dot"
                    style={{ background: RARITY_COLOR[item.rarity] }}
                    title={RARITY_LABEL[item.rarity]}
                  />
                </div>
              ) : (
                <div className="ed-slot-empty">Empty</div>
              )}
              {item && (
                <button
                  className="ed-unequip-btn"
                  title="Unequip"
                  onClick={(e) => { e.stopPropagation(); void unequip(slot) }}
                  aria-label={`Unequip ${item.name}`}
                >
                  ✕
                </button>
              )}
            </button>
          )
        })}
      </div>

      {/* Slot-filtered owned item picker */}
      {activeSlot && (
        <div className="ed-picker">
          <div className="ed-picker-header">
            <span>
              {SLOTS.find((s) => s.slot === activeSlot)?.icon}{' '}
              {SLOTS.find((s) => s.slot === activeSlot)?.label} — owned items
            </span>
            <button className="ed-picker-close" onClick={() => setActiveSlot(null)}>✕</button>
          </div>

          {slotItems.length === 0 ? (
            <p className="ed-picker-empty">No owned items for this slot yet. Visit the Shop tab!</p>
          ) : (
            <div className="ed-picker-grid">
              {/* "None" option to clear the slot */}
              <button
                className="ed-picker-none"
                onClick={() => { void unequip(activeSlot); setActiveSlot(null) }}
              >
                <span className="ed-picker-none-icon">🚫</span>
                <span>None</span>
              </button>

              {slotItems.map(({ itemId }) => {
                const item     = getCatalogItem(itemId)
                if (!item) return null
                const isEquipped = equipped[activeSlot] === itemId
                return (
                  <button
                    key={itemId}
                    className={['ed-picker-item', isEquipped ? 'ed-picker-item-equipped' : ''].filter(Boolean).join(' ')}
                    onClick={() => { void equip(itemId); setActiveSlot(null) }}
                    aria-label={`Equip ${item.name}`}
                  >
                    <img
                      src={item.thumbnail}
                      alt={item.name}
                      loading="lazy"
                      onError={(e) => { (e.target as HTMLImageElement).src = '/marketplace/thumbnails/placeholder.webp' }}
                    />
                    <span
                      className="ed-picker-rarity"
                      style={{ background: RARITY_COLOR[item.rarity] }}
                    />
                    <span className="ed-picker-name">{item.name}</span>
                    {isEquipped && <span className="ed-picker-check">✓</span>}
                  </button>
                )
              })}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
