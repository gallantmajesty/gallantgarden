import { useState } from 'react'
import { useEquipment } from '../../store/equipment'
import { getCatalogItem } from '../../marketplace/catalog'
import { RARITY_COLOR, type EquipSlot } from '../../marketplace/types'
import type { EquipmentPreset } from '../../marketplace/types'
import './PresetManager.css'

const DEFAULT_PRESET_TEMPLATES = [
  { name: 'Casual',     icon: '👕' },
  { name: 'Study Mode', icon: '📚' },
  { name: 'Fantasy',    icon: '✨' },
]

/**
 * PresetManager — save, rename, apply, and delete outfit presets.
 * Presets are named snapshots of the currently equipped slots.
 * One-click switching lets users jump between Casual / Study Mode / Fantasy.
 */
export function PresetManager() {
  const { presets, equipped, savePreset, applyPreset, deletePreset, renamePreset } = useEquipment()
  const [newName,  setNewName]  = useState('')
  const [editId,   setEditId]   = useState<string | null>(null)
  const [editName, setEditName] = useState('')

  const handleSave = () => {
    const name = newName.trim() || `Preset ${presets.length + 1}`
    savePreset(name)
    setNewName('')
  }

  const handleRename = (id: string) => {
    const trimmed = editName.trim()
    if (trimmed) renamePreset(id, trimmed)
    setEditId(null)
    setEditName('')
  }

  // Count how many slots are filled in a preset
  const filledCount = (preset: EquipmentPreset) =>
    Object.values(preset.slots).filter(Boolean).length

  return (
    <div className="pm-root">
      <h3 className="pm-title">🎭 Outfit Presets</h3>
      <p className="pm-subtitle">Save your current outfit as a preset for one-click switching.</p>

      {/* Save current outfit */}
      <div className="pm-save-row">
        <input
          className="pm-input"
          type="text"
          placeholder="Preset name (e.g. Study Mode)"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSave()}
          maxLength={32}
        />
        <button className="pm-btn-save" onClick={handleSave}>
          💾 Save Current Outfit
        </button>
      </div>

      {/* Quick-start templates for empty state */}
      {presets.length === 0 && (
        <div className="pm-empty">
          <p>No presets yet. Equip some items and save your first outfit!</p>
          <div className="pm-templates">
            {DEFAULT_PRESET_TEMPLATES.map((t) => (
              <button
                key={t.name}
                className="pm-template-btn"
                onClick={() => savePreset(t.name)}
              >
                {t.icon} {t.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Preset list */}
      <div className="pm-list">
        {presets.map((preset) => {
          const isEditing = editId === preset.id
          const slots = Object.entries(preset.slots).filter(([, v]) => v != null) as [EquipSlot, string][]

          return (
            <div key={preset.id} className="pm-card">
              {/* Header */}
              <div className="pm-card-header">
                {isEditing ? (
                  <div className="pm-rename-row">
                    <input
                      className="pm-input pm-rename-input"
                      autoFocus
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleRename(preset.id)
                        if (e.key === 'Escape') { setEditId(null); setEditName('') }
                      }}
                      maxLength={32}
                    />
                    <button className="pm-btn-confirm" onClick={() => handleRename(preset.id)}>✓</button>
                    <button className="pm-btn-cancel" onClick={() => { setEditId(null); setEditName('') }}>✕</button>
                  </div>
                ) : (
                  <>
                    <span className="pm-card-name">{preset.name}</span>
                    <span className="pm-card-meta">{filledCount(preset)} items</span>
                  </>
                )}
              </div>

              {/* Slot preview thumbnails */}
              <div className="pm-slot-preview">
                {slots.length === 0 ? (
                  <span className="pm-no-items">Empty preset</span>
                ) : (
                  slots.map(([slot, itemId]) => {
                    const item = getCatalogItem(itemId)
                    if (!item) return null
                    return (
                      <div key={slot} className="pm-slot-thumb" title={`${slot.replace(/_/g,' ')}: ${item.name}`}>
                        <img
                          src={item.thumbnail}
                          alt={item.name}
                          loading="lazy"
                          onError={(e) => { (e.target as HTMLImageElement).src = '/marketplace/thumbnails/placeholder.webp' }}
                        />
                        <span
                          className="pm-slot-rarity"
                          style={{ background: RARITY_COLOR[item.rarity] }}
                        />
                      </div>
                    )
                  })
                )}
              </div>

              {/* Actions */}
              <div className="pm-card-actions">
                <button
                  className="pm-btn-apply"
                  onClick={() => void applyPreset(preset.id)}
                  title="Apply this preset"
                >
                  ⚡ Apply
                </button>
                <button
                  className="pm-btn-rename"
                  onClick={() => { setEditId(preset.id); setEditName(preset.name) }}
                  title="Rename preset"
                  disabled={isEditing}
                >
                  ✏️
                </button>
                <button
                  className="pm-btn-delete"
                  onClick={() => deletePreset(preset.id)}
                  title="Delete preset"
                >
                  🗑️
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Current equipped summary */}
      <div className="pm-current">
        <h4>Current Outfit</h4>
        <div className="pm-current-slots">
          {(Object.entries(equipped) as [EquipSlot, string | null][])
            .filter(([, v]) => v)
            .map(([slot, itemId]) => {
              const item = itemId ? getCatalogItem(itemId) : null
              if (!item) return null
              return (
                <div key={slot} className="pm-current-item">
                  <img src={item.thumbnail} alt={item.name} loading="lazy"
                    onError={(e) => { (e.target as HTMLImageElement).src = '/marketplace/thumbnails/placeholder.webp' }} />
                  <div className="pm-current-item-info">
                    <span className="pm-current-slot">{slot.replace(/_/g, ' ')}</span>
                    <span className="pm-current-name">{item.name}</span>
                  </div>
                </div>
              )
            })}
        </div>
      </div>
    </div>
  )
}
