import { memo } from 'react'
import { RARITY_COLOR, RARITY_LABEL, type CatalogItem } from '../../marketplace/types'
import './ItemCard.css'

interface ItemCardProps {
  item:     CatalogItem
  owned:    boolean
  equipped: boolean
  selected: boolean
  onEquip:  () => void
  onTryOn:  () => void
  onSelect: () => void
}

/** A single marketplace item card — memoised so the virtualised grid never
 *  re-renders cards whose props haven't changed. */
export const ItemCard = memo(function ItemCard({
  item, owned, equipped, selected, onEquip, onTryOn, onSelect,
}: ItemCardProps) {
  return (
    <article
      className={[
        'ic-card',
        owned    ? 'ic-owned'    : '',
        equipped ? 'ic-equipped' : '',
        selected ? 'ic-selected' : '',
      ].filter(Boolean).join(' ')}
      onClick={onSelect}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && onSelect()}
      aria-pressed={selected}
      aria-label={`${item.name}, ${RARITY_LABEL[item.rarity]}, ${owned ? 'owned' : `${item.price} coins`}`}
    >
      {/* ── Thumbnail ──────────────────────────────────────────────────── */}
      <div className="ic-thumb">
        <img
          src={item.thumbnail}
          alt={item.name}
          loading="lazy"
          decoding="async"
          onError={(e) => {
            const img = e.target as HTMLImageElement
            img.src = '/marketplace/thumbnails/placeholder.webp'
          }}
        />
        {/* Rarity gem */}
        <span
          className="ic-rarity-gem"
          style={{ background: RARITY_COLOR[item.rarity] }}
          title={RARITY_LABEL[item.rarity]}
        />
        {/* Badges */}
        {equipped && <span className="ic-badge ic-badge-equipped">Equipped</span>}
        {owned && !equipped && <span className="ic-badge ic-badge-owned">Owned</span>}
        {item.price === 0 && !owned && <span className="ic-badge ic-badge-free">Free</span>}
      </div>

      {/* ── Info ───────────────────────────────────────────────────────── */}
      <div className="ic-info">
        <span className="ic-name">{item.name}</span>
        <span className="ic-rarity" style={{ color: RARITY_COLOR[item.rarity] }}>
          {RARITY_LABEL[item.rarity]}
        </span>
        {item.price > 0 && !owned
          ? <span className="ic-price">{item.price} 🌟</span>
          : item.price === 0 && !owned
          ? <span className="ic-price ic-price-free">Free</span>
          : null
        }
      </div>

      {/* ── Action row ─────────────────────────────────────────────────── */}
      <div className="ic-actions" onClick={(e) => e.stopPropagation()}>
        <button
          className="ic-btn-try"
          onClick={onTryOn}
          title="Try on"
          aria-label={`Try on ${item.name}`}
        >
          👁 Try
        </button>
        {owned && (
          <button
            className={equipped ? 'ic-btn-unequip' : 'ic-btn-equip'}
            onClick={onEquip}
            aria-label={equipped ? `Unequip ${item.name}` : `Equip ${item.name}`}
          >
            {equipped ? 'Unequip' : 'Equip'}
          </button>
        )}
      </div>
    </article>
  )
})
