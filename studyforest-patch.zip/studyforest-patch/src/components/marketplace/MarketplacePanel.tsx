import { useState, useMemo, useCallback, useRef, useEffect } from 'react'
import { useInventory } from '../../store/inventory'
import { useEquipment } from '../../store/equipment'
import { CATALOG, getCatalogItem } from '../../marketplace/catalog'
import {
  RARITY_LABEL, RARITY_COLOR,
  type CatalogItem, type EquipSlot, type Rarity,
} from '../../marketplace/types'
import { ItemCard } from './ItemCard'
import { EquipmentDresser } from './EquipmentDresser'
import { PresetManager } from './PresetManager'
import './MarketplacePanel.css'

// ── Category display groups ───────────────────────────────────────────────────

const CATEGORY_GROUPS = [
  { label: 'All',       value: 'all' },
  { label: '👕 Clothing', value: 'clothing' },
  { label: '💇 Hair',     value: 'hair' },
  { label: '🕶️ Accessories', value: 'accessories' },
  { label: '✨ Effects',  value: 'effects' },
  { label: '📚 Study Props', value: 'study' },
  { label: '🎒 Owned',    value: 'owned' },
] as const

type TabValue = typeof CATEGORY_GROUPS[number]['value']

const CATEGORY_FILTER: Record<TabValue, (c: CatalogItem) => boolean> = {
  all:         () => true,
  clothing:    (c) => ['shirt','hoodie','jacket','pants','shorts','skirt','dress','shoes','socks'].includes(c.category),
  hair:        (c) => c.category.startsWith('hair_'),
  accessories: (c) => ['glasses','hat','cap','headphones','mask','scarf','backpack'].includes(c.category),
  effects:     (c) => ['wings','aura','floating_particles','magical_trail','glow_effect'].includes(c.category),
  study:       (c) => c.category.startsWith('prop_'),
  owned:       () => false,   // handled specially — filtered against inventory
}

type SortKey = 'default' | 'newest' | 'rarity_asc' | 'rarity_desc' | 'price_asc' | 'price_desc' | 'owned'

const RARITY_RANK: Record<Rarity, number> = { common: 0, uncommon: 1, rare: 2, epic: 3, legendary: 4 }

export function MarketplacePanel({ onClose }: { onClose?: () => void }) {
  const { owns, ownedList } = useInventory()
  const { equipped, equip, unequip, tryOn, clearPreview, previewing } = useEquipment()

  const [tab,     setTab]     = useState<TabValue>('all')
  const [search,  setSearch]  = useState('')
  const [sort,    setSort]    = useState<SortKey>('default')
  const [rarityFilter, setRarityFilter] = useState<Rarity | 'all'>('all')
  const [view,    setView]    = useState<'shop' | 'dresser' | 'presets'>('shop')
  const [selected, setSelected] = useState<CatalogItem | null>(null)

  // Virtualized list state
  const ITEM_HEIGHT = 220
  const COLS        = 3
  const [scrollTop, setScrollTop] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const containerHeight = 540

  // ── Filtered + sorted items ───────────────────────────────────────────────
  const items = useMemo(() => {
    let list = CATALOG.filter(tab === 'owned'
      ? (c) => owns(c.id)
      : CATEGORY_FILTER[tab],
    )

    if (rarityFilter !== 'all') list = list.filter((c) => c.rarity === rarityFilter)

    if (search.trim()) {
      const q = search.trim().toLowerCase()
      list = list.filter((c) => c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q))
    }

    switch (sort) {
      case 'newest':
        // Owned-first then catalog default for "newest" feel
        list = [...list].sort((a, b) => {
          const ao = owns(a.id) ? 1 : 0
          const bo = owns(b.id) ? 1 : 0
          return bo - ao
        })
        break
      case 'rarity_desc':
        list = [...list].sort((a, b) => RARITY_RANK[b.rarity] - RARITY_RANK[a.rarity])
        break
      case 'rarity_asc':
        list = [...list].sort((a, b) => RARITY_RANK[a.rarity] - RARITY_RANK[b.rarity])
        break
      case 'price_asc':
        list = [...list].sort((a, b) => a.price - b.price)
        break
      case 'price_desc':
        list = [...list].sort((a, b) => b.price - a.price)
        break
      case 'owned':
        list = [...list].sort((a, b) => (owns(b.id) ? 1 : 0) - (owns(a.id) ? 1 : 0))
        break
    }

    return list
  }, [tab, search, sort, rarityFilter, owns])

  // ── Virtualized grid ──────────────────────────────────────────────────────
  const rowCount       = Math.ceil(items.length / COLS)
  const totalHeight    = rowCount * ITEM_HEIGHT
  const startRow       = Math.floor(scrollTop / ITEM_HEIGHT)
  const visibleRows    = Math.ceil(containerHeight / ITEM_HEIGHT) + 2
  const endRow         = Math.min(startRow + visibleRows, rowCount)
  const visibleItems   = items.slice(startRow * COLS, endRow * COLS)
  const offsetY        = startRow * ITEM_HEIGHT

  const handleScroll = useCallback((e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop)
  }, [])

  const handleEquip = useCallback(async (item: CatalogItem) => {
    if (!owns(item.id)) return
    const isEquipped = Object.values(equipped).includes(item.id)
    if (isEquipped) await unequip(item.slot as EquipSlot)
    else await equip(item.id)
  }, [owns, equipped, equip, unequip])

  const handleTryOn = useCallback((item: CatalogItem) => {
    tryOn(item.id)
    setSelected(item)
  }, [tryOn])

  return (
    <div className="mp-panel" role="dialog" aria-label="Marketplace">
      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="mp-header">
        <div className="mp-title">
          <span className="mp-icon">🛍️</span>
          <h2>Marketplace</h2>
          {previewing && (
            <span className="mp-preview-badge">
              Preview active
              <button onClick={clearPreview} className="mp-clear-preview">✕</button>
            </span>
          )}
        </div>
        <div className="mp-header-tabs">
          <button className={view === 'shop'    ? 'active' : ''} onClick={() => setView('shop')}>   Shop      </button>
          <button className={view === 'dresser' ? 'active' : ''} onClick={() => setView('dresser')}>Wardrobe  </button>
          <button className={view === 'presets' ? 'active' : ''} onClick={() => setView('presets')}>Presets   </button>
        </div>
        {onClose && <button className="mp-close" onClick={onClose} aria-label="Close">✕</button>}
      </div>

      {/* ── Shop view ──────────────────────────────────────────────────────── */}
      {view === 'shop' && (
        <>
          {/* Category tabs */}
          <div className="mp-tabs" role="tablist">
            {CATEGORY_GROUPS.map((g) => (
              <button
                key={g.value}
                role="tab"
                aria-selected={tab === g.value}
                className={tab === g.value ? 'active' : ''}
                onClick={() => { setTab(g.value); setScrollTop(0) }}
              >
                {g.label}
                {g.value === 'owned' && (
                  <span className="mp-owned-count">{ownedList().length}</span>
                )}
              </button>
            ))}
          </div>

          {/* Toolbar */}
          <div className="mp-toolbar">
            <div className="mp-search">
              <span>🔍</span>
              <input
                type="search"
                placeholder="Search items…"
                value={search}
                onChange={(e) => { setSearch(e.target.value); setScrollTop(0) }}
              />
              {search && <button className="mp-search-clear" onClick={() => setSearch('')}>✕</button>}
            </div>

            <select
              className="mp-select"
              value={rarityFilter}
              onChange={(e) => setRarityFilter(e.target.value as Rarity | 'all')}
            >
              <option value="all">All rarities</option>
              {(['common','uncommon','rare','epic','legendary'] as Rarity[]).map((r) => (
                <option key={r} value={r}>{RARITY_LABEL[r]}</option>
              ))}
            </select>

            <select
              className="mp-select"
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
            >
              <option value="default">Sort: Default</option>
              <option value="newest">Sort: Newest</option>
              <option value="rarity_desc">Rarity: High → Low</option>
              <option value="rarity_asc">Rarity: Low → High</option>
              <option value="price_asc">Price: Low → High</option>
              <option value="price_desc">Price: High → Low</option>
              <option value="owned">Owned first</option>
            </select>
          </div>

          {/* Results count */}
          <div className="mp-results-count">
            {items.length} item{items.length !== 1 ? 's' : ''}
          </div>

          {/* Virtualized grid */}
          <div
            ref={containerRef}
            className="mp-grid-scroll"
            style={{ height: containerHeight, overflowY: 'auto' }}
            onScroll={handleScroll}
          >
            <div style={{ height: totalHeight, position: 'relative' }}>
              <div
                className="mp-grid"
                style={{ transform: `translateY(${offsetY}px)` }}
              >
                {visibleItems.map((item) => (
                  <ItemCard
                    key={item.id}
                    item={item}
                    owned={owns(item.id)}
                    equipped={Object.values(equipped).includes(item.id)}
                    selected={selected?.id === item.id}
                    onEquip={() => handleEquip(item)}
                    onTryOn={() => handleTryOn(item)}
                    onSelect={() => setSelected(selected?.id === item.id ? null : item)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Item detail drawer */}
          {selected && (
            <div className="mp-detail">
              <div className="mp-detail-thumb">
                <img
                  src={selected.thumbnail}
                  alt={selected.name}
                  loading="lazy"
                  onError={(e) => { (e.target as HTMLImageElement).src = '/marketplace/thumbnails/placeholder.webp' }}
                />
              </div>
              <div className="mp-detail-info">
                <h3>{selected.name}</h3>
                <span className="mp-detail-rarity" style={{ color: RARITY_COLOR[selected.rarity] }}>
                  {RARITY_LABEL[selected.rarity]}
                </span>
                <p>{selected.description}</p>
                <div className="mp-detail-meta">
                  <span>Category: {selected.category.replace(/_/g, ' ')}</span>
                  <span>Slot: {selected.slot.replace(/_/g, ' ')}</span>
                  {selected.price > 0 && <span>Price: {selected.price} 🌟</span>}
                  {selected.price === 0 && <span className="mp-free">Free</span>}
                </div>
                <div className="mp-detail-actions">
                  <button
                    className="mp-btn-try"
                    onClick={() => handleTryOn(selected)}
                  >
                    Try On
                  </button>
                  {owns(selected.id) && (
                    <button
                      className={Object.values(equipped).includes(selected.id) ? 'mp-btn-unequip' : 'mp-btn-equip'}
                      onClick={() => handleEquip(selected)}
                    >
                      {Object.values(equipped).includes(selected.id) ? 'Unequip' : 'Equip'}
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ── Dresser view ───────────────────────────────────────────────────── */}
      {view === 'dresser' && <EquipmentDresser />}

      {/* ── Presets view ───────────────────────────────────────────────────── */}
      {view === 'presets' && <PresetManager />}
    </div>
  )
}
