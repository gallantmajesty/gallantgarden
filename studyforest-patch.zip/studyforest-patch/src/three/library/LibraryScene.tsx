import {
  Component,
  Suspense,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { PerformanceMonitor, Sparkles } from '@react-three/drei'
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing'
import { KernelSize } from 'postprocessing'
import type { Material, Mesh, Object3D, Texture } from 'three'

import { HALL } from './layout'
import { LibraryShell } from './LibraryShell'
import { Bookshelves } from './Bookshelf'
import { StudyTables } from './StudyTable'
import { Decor } from './Decor'
import { Lanterns } from './Lanterns'
import { KnowledgeTree } from './KnowledgeTree'
import { Exterior } from './Exterior'
import { DayNightWeather } from './DayNightWeather'
import { PlayerController } from './PlayerController'
import { RemotePlayers } from './RemotePlayers'
import { useScenePreset } from '../../store/quality'

class SoftBoundary extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() { return this.state.failed ? null : this.props.children }
}

export function LibraryScene({ onReady }: { onReady?: () => void }) {
  const preset = useScenePreset()
  const [dpr, setDpr] = useState(preset.dpr)
  useEffect(() => setDpr(preset.dpr), [preset.dpr])

  // ── DPR floor: 0.85 → 0.6 ────────────────────────────────────────────────
  // The old floor of 0.85 gave the PerformanceMonitor only 0–0.15 headroom —
  // basically nothing on integrated GPUs.  With 0.6 the governor can genuinely
  // halve fill-rate cost on weak devices and is the single biggest FPS win.
  const DPR_FLOOR = 0.6

  // ── Warm-up gate: 8 s → 5 s ──────────────────────────────────────────────
  // 5 s covers shader-compilation + Suspense waterfall without leaving the
  // governor unnecessarily blind.
  const [govReady, setGovReady] = useState(false)
  useEffect(() => { const t = setTimeout(() => setGovReady(true), 5000); return () => clearTimeout(t) }, [])

  return (
    <Canvas
      shadows={preset.shadows ? 'soft' : false}
      dpr={dpr}
      gl={{ antialias: false, powerPreference: 'high-performance' }}
      camera={{ position: [0, 1.7, 8], fov: 68, near: 0.08, far: preset.far }}
      onCreated={() => onReady?.()}
    >
      {govReady && (
        <PerformanceMonitor
          bounds={(rate) => (rate > 90 ? [55, 90] : [35, 58])}
          flipflops={3}
          factor={1}
          onChange={({ factor }) =>
            setDpr(Math.round((DPR_FLOOR + (preset.dpr - DPR_FLOOR) * factor) * 100) / 100)
          }
          onFallback={() => setDpr(DPR_FLOOR)}
        />
      )}

      <QualitySync shadows={preset.shadows} />
      <TextureQualitySync anisotropy={preset.anisotropy} />

      <SoftBoundary>
        <Suspense fallback={null}>
          <DayNightWeather shadows={preset.shadows} fog={preset.fog}
            rainScale={preset.rainScale} shadowMap={preset.shadowMap} rainDrops={preset.rainDrops} />
          <Exterior count={preset.forest} mountains={preset.mountains} clouds={preset.clouds} />
        </Suspense>
      </SoftBoundary>

      <ambientLight intensity={0.44} color="#ffd9a8" />
      <LibraryShell />
      <Bookshelves />
      <StudyTables />
      <Decor />
      <Lanterns />
      <KnowledgeTree />

      {preset.dust > 0 && (
        <Sparkles count={preset.dust}
          scale={[HALL.halfW * 2, HALL.wallH, HALL.halfL * 2]}
          position={[0, HALL.wallH / 2, 0]}
          size={2.6} speed={0.16} color="#ffe6b0" opacity={0.5} />
      )}

      <PlayerController />
      <RemotePlayers />
      <PerfLogger />

      {preset.bloom && (
        <EffectComposer enableNormalPass={false} multisampling={0}>
          <Bloom luminanceThreshold={0.75} luminanceSmoothing={0.3}
            intensity={0.5} kernelSize={KernelSize.SMALL} mipmapBlur />
          <Vignette eskil={false} offset={0.14} darkness={0.85} />
        </EffectComposer>
      )}
    </Canvas>
  )
}

function QualitySync({ shadows }: { shadows: boolean }) {
  const gl = useThree((s) => s.gl)
  useEffect(() => { gl.shadowMap.enabled = shadows; gl.shadowMap.needsUpdate = true }, [gl, shadows])
  return null
}

const TEX_KEYS = ['map','emissiveMap','normalMap','roughnessMap','metalnessMap','aoMap'] as const

function TextureQualitySync({ anisotropy }: { anisotropy: number }) {
  const gl = useThree((s) => s.gl)
  const scene = useThree((s) => s.scene)
  useEffect(() => {
    const a = Math.min(anisotropy, gl.capabilities.getMaxAnisotropy())
    scene.traverse((o) => {
      const mat = (o as Mesh).material as Material | Material[] | undefined
      if (!mat) return
      for (const m of Array.isArray(mat) ? mat : [mat]) {
        for (const key of TEX_KEYS) {
          const tex = (m as Record<string, Texture | null>)[key]
          if (tex?.isTexture && tex.anisotropy !== a) { tex.anisotropy = a; tex.needsUpdate = true }
        }
      }
    })
  }, [anisotropy, gl, scene])
  return null
}

/**
 * PerfLogger — comprehensive render-stats report to the browser console.
 *
 * Covers the full spec audit checklist:
 *   FPS · draw calls · triangles · active meshes · active lights (pt/dir/spot)
 *   shadow casters · shader programs · texture count · geometry count
 *
 * GPU frame time is NOT available from WebGL info; use Chrome DevTools
 * Rendering panel (Ctrl+Shift+I → More tools → Rendering → Frame rendering stats)
 * or chrome://tracing for GPU-side timing.
 *
 * Reports every 2 s for first 15 s (warm-up phase), then every 10 s.
 * Ends with a ranked list of suspected bottlenecks so engineers know where to look.
 */
function PerfLogger() {
  const gl    = useThree((s) => s.gl)
  const scene = useThree((s) => s.scene)
  const acc   = useRef({ f: 0, t: 0, total: 0 })

  useFrame((_, dt) => {
    const a = acc.current
    a.f++; a.t += dt; a.total += dt
    const interval = a.total < 15 ? 2 : 10
    if (a.t < interval) return

    const fps = a.f / a.t
    const r = gl.info.render
    const m = gl.info.memory

    let pt = 0, dir = 0, spot = 0, sc = 0, mc = 0
    scene.traverse((o: Object3D) => {
      if (o.type === 'PointLight')       pt++
      else if (o.type === 'DirectionalLight') dir++
      else if (o.type === 'SpotLight')   spot++
      // @ts-expect-error mesh check
      if (o.castShadow && (o.isMesh || o.isSkinnedMesh)) sc++
      // @ts-expect-error mesh check
      if (o.isMesh || o.isSkinnedMesh) mc++
    })

    const lights = pt + dir + spot
    const bn: string[] = []
    if (fps < 30)              bn.push(`⚠ LOW FPS ${fps.toFixed(1)}`)
    if (r.calls > 200)         bn.push(`HIGH draw calls ${r.calls} → instance/merge static props`)
    if (r.triangles > 400_000) bn.push(`HIGH tris ${(r.triangles/1000).toFixed(0)}k → LOD/cull distant`)
    if (lights > 6)            bn.push(`MANY lights ${lights} (pt:${pt} dir:${dir} spot:${spot}) → emissive+bloom`)
    if (sc > 30)               bn.push(`MANY shadow casters ${sc} → castShadow=false on static props`)
    if (mc > 500 && fps < 30)  bn.push(`HIGH mesh count ${mc} → static batching`)
    if (m.textures > 80)       bn.push(`HIGH textures ${m.textures} → atlas/reduce`)
    if (!bn.length)            bn.push('✓ No urgent bottleneck')

    console.info(
      `[FocusLily perf] ${fps.toFixed(1)} fps` +
      ` | draws:${r.calls} tris:${(r.triangles/1000).toFixed(0)}k` +
      ` | progs:${gl.info.programs?.length ?? 0} geo:${m.geometries} tex:${m.textures}` +
      ` | meshes:${mc} lights:${lights}(pt:${pt} dir:${dir} spot:${spot})` +
      ` | shadowCasters:${sc}` +
      `\n  ► ${bn.join('\n  ► ')}`
    )
    a.f = 0; a.t = 0
  })
  return null
}
