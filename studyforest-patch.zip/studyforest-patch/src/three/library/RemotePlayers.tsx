import { useRef } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Group, MathUtils, Vector3 } from 'three'
import { CharacterAvatar } from '../../avatar/CharacterAvatar'
import type { Locomotion } from '../../avatar/animation'
import type { AvatarConfig } from '../../avatar/config'
import type { Lod } from '../../avatar/AvatarAnimator'
import { getTarget, useRealmNet } from '../../multiplayer/net'

// ────────────────────────────────────────────────────────────────────────────
// RemotePlayers — all other avatars in the realm, rendered from the live
// roster.  The KEY performance fix for the 1-10 FPS problem:
//
// BEFORE: every remote avatar passed lod='near' unconditionally, so 20+ bodies
//         each updated ALL bones EVERY frame → CPU-bound collapse.
//
// AFTER:  each avatar's LOD tier is computed from camera distance every frame
//         and written into a mutable ref that CharacterAvatar / AvatarAnimator
//         read.  At 12 m+ the avatar drops to 'far' (every-3rd-frame updates),
//         and at 28 m+ to 'cull' (animation frozen — avatar moves but poses).
//         No allocations inside the hot path; reuses module-level Vector3s.
// ────────────────────────────────────────────────────────────────────────────

const LOD_FAR  = 12   // metres  full → reduced-rate
const LOD_CULL = 28   // metres  reduced-rate → frozen

const _cam = new Vector3()
const _pos = new Vector3()
const CHASE = 12  // interpolation speed (frame-rate independent expo ease)

export function RemotePlayers() {
  const roster = useRealmNet((s) => s.roster)
  return (
    <>
      {Object.values(roster).map((p) => (
        <RemotePlayerAvatar key={p.id} id={p.id} config={p.avatar} />
      ))}
    </>
  )
}

function RemotePlayerAvatar({ id, config }: { id: string; config: AvatarConfig }) {
  const group  = useRef<Group>(null)
  const camera = useThree((s) => s.camera)
  const loco   = useRef<Locomotion>({ speed: 0, grounded: true, vy: 0, turnRate: 0, seated: false })
  const render = useRef<{ x: number; y: number; z: number; yaw: number } | null>(null)
  const lodRef = useRef<Lod>('near')

  useFrame((_, dtRaw) => {
    const g = group.current
    if (!g) return
    const t = getTarget(id)
    if (!t) return

    if (!render.current) render.current = { x: t.x, y: t.y, z: t.z, yaw: t.yaw }
    const r  = render.current
    const dt = Math.min(dtRaw, 0.05)
    const k  = 1 - Math.exp(-dt * CHASE)

    r.x += (t.x - r.x) * k
    r.y += (t.y - r.y) * k
    r.z += (t.z - r.z) * k
    // shortest-arc yaw so we never spin the long way round
    const dYaw = Math.atan2(Math.sin(t.yaw - r.yaw), Math.cos(t.yaw - r.yaw))
    r.yaw += dYaw * k

    g.position.set(r.x, r.y, r.z)
    g.rotation.y = r.yaw

    loco.current.speed    = t.speed
    loco.current.grounded = t.grounded
    loco.current.seated   = t.seated

    // ── distance LOD (THE primary FPS fix) ──────────────────────────────────
    _cam.copy(camera.position)
    _pos.set(r.x, r.y, r.z)
    const d = _cam.distanceTo(_pos)
    lodRef.current = d < LOD_FAR ? 'near' : d < LOD_CULL ? 'far' : 'cull'
  })

  return (
    <group ref={group}>
      <CharacterAvatar config={config} locomotion={loco} lod={lodRef} />
    </group>
  )
}
