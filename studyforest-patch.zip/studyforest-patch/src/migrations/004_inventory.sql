-- ============================================================================
-- Migration 004 — Persistent Inventory & Equipment System
-- Run this against your Supabase / InsForge database.
-- All tables use RLS so users can only read/write their own rows.
-- ============================================================================

-- ── 1. User Inventory ────────────────────────────────────────────────────────
-- Stores every item a user has ever obtained.
-- item_id is a stable FK to the client-side catalog (catalog.ts).
-- Items are NEVER deleted unless explicitly revoked via the admin_revoke() fn.

create table if not exists public.user_inventory (
  id           uuid        primary key default gen_random_uuid(),
  user_id      uuid        not null references auth.users(id) on delete cascade,
  item_id      text        not null,
  obtained_at  timestamptz not null default now(),
  source       text        not null check (source in (
                             'purchase','starter','earned','gifted','unlocked','admin'
                           )),
  constraint uq_user_item unique (user_id, item_id)
);

-- Indexes for fast per-user lookups (thousands of items stay O(log n))
create index if not exists idx_user_inventory_user_id  on public.user_inventory (user_id);
create index if not exists idx_user_inventory_item_id  on public.user_inventory (item_id);
create index if not exists idx_user_inventory_obtained on public.user_inventory (user_id, obtained_at desc);

-- RLS
alter table public.user_inventory enable row level security;

drop policy if exists "users read own inventory"   on public.user_inventory;
drop policy if exists "users insert own inventory" on public.user_inventory;
drop policy if exists "users upsert own inventory" on public.user_inventory;

create policy "users read own inventory"
  on public.user_inventory for select
  using (auth.uid() = user_id);

create policy "users insert own inventory"
  on public.user_inventory for insert
  with check (auth.uid() = user_id);

-- Upsert support (insert or do nothing on conflict)
create policy "users upsert own inventory"
  on public.user_inventory for update
  using (auth.uid() = user_id);


-- ── 2. User Equipped Items ───────────────────────────────────────────────────
-- Only the 8 currently equipped item IDs per user.
-- This is what gets synced to other players — never the full inventory.

create table if not exists public.user_equipped (
  id       uuid primary key default gen_random_uuid(),
  user_id  uuid not null references auth.users(id) on delete cascade,
  slot     text not null check (slot in (
             'hair','top','bottom','shoes',
             'face_accessory','head_accessory','back_accessory','effect'
           )),
  item_id  text,   -- null = slot empty
  updated_at timestamptz not null default now(),
  constraint uq_user_slot unique (user_id, slot)
);

create index if not exists idx_user_equipped_user_id on public.user_equipped (user_id);

alter table public.user_equipped enable row level security;

drop policy if exists "users read own equipped"   on public.user_equipped;
drop policy if exists "users write own equipped"  on public.user_equipped;

create policy "users read own equipped"
  on public.user_equipped for select
  using (auth.uid() = user_id);

create policy "users write own equipped"
  on public.user_equipped for all
  using  (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ── 3. Equipment Presets ─────────────────────────────────────────────────────
-- Named outfit snapshots (Casual / Study Mode / Fantasy / custom).

create table if not exists public.user_presets (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  name       text not null,
  slots      jsonb not null default '{}'::jsonb,  -- { slot: item_id | null }
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_user_presets_user_id on public.user_presets (user_id);

alter table public.user_presets enable row level security;

drop policy if exists "users manage own presets" on public.user_presets;

create policy "users manage own presets"
  on public.user_presets for all
  using  (auth.uid() = user_id)
  with check (auth.uid() = user_id);


-- ── 4. Admin Revoke Function ─────────────────────────────────────────────────
-- The ONLY way to remove an item from a user's inventory.
-- Must be called by a service-role key (not accessible from the client).

create or replace function public.admin_revoke_item(
  p_user_id uuid,
  p_item_id text
)
returns void
language plpgsql
security definer   -- runs as the function owner (service role), not the caller
as $$
begin
  delete from public.user_inventory
  where  user_id = p_user_id
  and    item_id = p_item_id;

  -- Also unequip if the item was in a slot
  update public.user_equipped
  set    item_id = null, updated_at = now()
  where  user_id = p_user_id
  and    item_id = p_item_id;
end;
$$;

-- Revoke execute from public so only service-role can call it
revoke execute on function public.admin_revoke_item(uuid, text) from public;


-- ── 5. Auto-timestamp trigger on user_equipped ───────────────────────────────

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_user_equipped_updated_at on public.user_equipped;
create trigger trg_user_equipped_updated_at
  before update on public.user_equipped
  for each row execute function public.set_updated_at();

drop trigger if exists trg_user_presets_updated_at on public.user_presets;
create trigger trg_user_presets_updated_at
  before update on public.user_presets
  for each row execute function public.set_updated_at();


-- ── 6. Starter kit helper ────────────────────────────────────────────────────
-- Called once from a Supabase Edge Function / webhook on user signup.
-- Grants the free starter items so new accounts have something to wear.

create or replace function public.grant_starter_kit(p_user_id uuid)
returns void
language plpgsql
security definer
as $$
declare
  starter_ids text[] := array[
    'tee_white','tee_grey','hoodie_navy','pants_dark','shorts_khaki',
    'sneakers_white','hair_short_brown','hair_twintails_black',
    'prop_pencil','backpack_school','prop_study_bag'
  ];
  item_id text;
begin
  foreach item_id in array starter_ids loop
    insert into public.user_inventory (user_id, item_id, source)
    values (p_user_id, item_id, 'starter')
    on conflict (user_id, item_id) do nothing;
  end loop;
end;
$$;

revoke execute on function public.grant_starter_kit(uuid) from public;


-- Done ✓
