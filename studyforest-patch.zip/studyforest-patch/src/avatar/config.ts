// AvatarConfig v4 — adds face/head/back/effect slots while staying backward-compatible.
// All new fields default to null so any existing v3 save is valid v4.

export const AVATAR_CONFIG_VERSION = 4 as const

export type SkinTone  = 'light' | 'lightMedium' | 'medium' | 'mediumDark' | 'dark'
export type EyeColor  = 'brown' | 'blue' | 'green' | 'amber' | 'grey' | 'violet' | 'red'
export type BodyType  = 'slim' | 'average' | 'broad'

export interface AvatarConfig {
  version:  typeof AVATAR_CONFIG_VERSION
  skin:     SkinTone
  eyeColor: EyeColor
  bodyType: BodyType
  // v3 slots (renderer implemented)
  hair:   string | null
  top:    string | null
  bottom: string | null
  shoes:  string | null
  // v4 slots (store & transmit; renderer handles each per-item)
  faceAccessory: string | null
  headAccessory: string | null
  backAccessory: string | null
  effect:        string | null
}

export const DEFAULT_AVATAR_CONFIG: AvatarConfig = {
  version: AVATAR_CONFIG_VERSION,
  skin: 'medium', eyeColor: 'brown', bodyType: 'average',
  hair: 'hair_short_brown', top: 'tee_white', bottom: 'pants_dark', shoes: 'sneakers_white',
  faceAccessory: null, headAccessory: null, backAccessory: null, effect: null,
}

export function migrateAvatarConfig(raw: unknown): AvatarConfig {
  if (!raw || typeof raw !== 'object') return { ...DEFAULT_AVATAR_CONFIG }
  const c = raw as Record<string, unknown>
  return {
    version:       AVATAR_CONFIG_VERSION,
    skin:          (c.skin      as SkinTone)       ?? DEFAULT_AVATAR_CONFIG.skin,
    eyeColor:      (c.eyeColor  as EyeColor)       ?? DEFAULT_AVATAR_CONFIG.eyeColor,
    bodyType:      (c.bodyType  as BodyType)       ?? DEFAULT_AVATAR_CONFIG.bodyType,
    hair:          (c.hair          as string|null) ?? DEFAULT_AVATAR_CONFIG.hair,
    top:           (c.top           as string|null) ?? DEFAULT_AVATAR_CONFIG.top,
    bottom:        (c.bottom        as string|null) ?? DEFAULT_AVATAR_CONFIG.bottom,
    shoes:         (c.shoes         as string|null) ?? DEFAULT_AVATAR_CONFIG.shoes,
    faceAccessory: (c.faceAccessory as string|null) ?? null,
    headAccessory: (c.headAccessory as string|null) ?? null,
    backAccessory: (c.backAccessory as string|null) ?? null,
    effect:        (c.effect        as string|null) ?? null,
  }
}

import type { EquipSlot } from '../marketplace/types'
export const EQUIP_SLOT_TO_CONFIG_KEY: Record<EquipSlot, keyof AvatarConfig | null> = {
  hair: 'hair', top: 'top', bottom: 'bottom', shoes: 'shoes',
  face_accessory: 'faceAccessory', head_accessory: 'headAccessory',
  back_accessory: 'backAccessory', effect: 'effect',
}
