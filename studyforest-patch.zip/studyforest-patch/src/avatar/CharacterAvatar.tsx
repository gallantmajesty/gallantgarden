import { Component, Suspense, useEffect, useMemo, useRef, type ReactNode } from 'react'
import { useFrame } from '@react-three/fiber'
import { useAnimations, useGLTF } from '@react-three/drei'
import { Box3, type Object3D } from 'three'
import { SkeletonUtils } from 'three-stdlib'
import { BASE_BODY } from './baseBody'
import { AvatarRig, type AvatarRigHandle } from './AvatarRig'
import { AvatarAnimator, type Lod } from './AvatarAnimator'
import { gaitAmount, type Locomotion } from './animation'
import type { AvatarConfig } from './config'

// ─────────────────────────────────────────────────────────────────────────────
// CharacterAvatar
//
// Renders one avatar body — the local player or any remote player.
// Supports two modes:
//   animated  (locomotion ref present) — plays idle/walk/run/jump clips
//   static    (no locomotion)          — frozen on idle mid-frame for editors
//
// LOD support (NEW — primary FPS fix):
//   lod ref is written every frame by RemotePlayers from camera distance.
//   'near'  → full animation updates every frame  (default for local player)
//   'far'   → every 3rd frame  (AvatarAnimator stride logic)
//   'cull'  → no animation updates — pose frozen
//   Local player always passes nearLod (always 'near').
// ─────────────────────────────────────────────────────────────────────────────

interface CharacterAvatarProps {
  config:     AvatarConfig
  locomotion?: React.RefObject<Locomotion>
  /** Mutable LOD ref written by RemotePlayers. Omit for local player = always 'near'. */
  lod?:       React.RefObject<Lod>
}

class ModelBoundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  render() { return this.state.failed ? this.props.fallback : this.props.children }
}

export function CharacterAvatar({ config, locomotion, lod }: CharacterAvatarProps) {
  const nearLod     = useRef<Lod>('near')
  const resolvedLod = lod ?? nearLod
  const rigRef      = useRef<AvatarRigHandle>(null)

  const fallback = (
    <group scale={BASE_BODY.scale} position={[0, BASE_BODY.yOffset, 0]}>
      <AvatarRig ref={rigRef} config={config} />
      {locomotion && <AvatarAnimator rig={rigRef} locomotion={locomotion} lod={resolvedLod} />}
    </group>
  )

  return (
    <ModelBoundary fallback={fallback}>
      <Suspense fallback={fallback}>
        <GLBCharacter config={config} locomotion={locomotion} lod={resolvedLod} />
      </Suspense>
    </ModelBoundary>
  )
}

function GLBCharacter({
  config, locomotion, lod,
}: { config: AvatarConfig; locomotion?: React.RefObject<Locomotion>; lod: React.RefObject<Lod> }) {
  const { scene, animations } = useGLTF(`/models/avatars/${BASE_BODY.model}`)

  const cloned = useMemo(() => {
    const c = SkeletonUtils.clone(scene)
    c.traverse((o: Object3D) => {
      // @ts-expect-error mesh check
      if (o.isMesh) { o.castShadow = true; o.receiveShadow = true }
    })
    return c
  }, [scene])

  const groundY = useMemo(() => {
    cloned.updateMatrixWorld(true)
    const box = new Box3().setFromObject(cloned)
    return Number.isFinite(box.min.y) ? -box.min.y : 0
  }, [cloned])

  const { actions } = useAnimations(animations, cloned)

  const findClip = (want: string) => {
    const key = Object.keys(actions).find((k) => k.toLowerCase().includes(want))
    return key ? actions[key] ?? null : null
  }

  const clips = useMemo(() => ({
    idle: findClip('idle'),
    walk: findClip('walk'),
    run:  findClip('run'),
    jump: findClip('jump'),
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [actions])

  const current = useRef(clips.idle ?? null)

  useEffect(() => {
    const start = clips.idle ?? clips.walk ?? Object.values(actions)[0] ?? null
    if (start) {
      start.reset().play()
      if (!locomotion) { start.time = start.getClip().duration * 0.5; start.paused = true }
      current.current = start
    }
    return () => Object.values(actions).forEach((a) => a?.stop())
  }, [actions, clips, locomotion])

  useFrame(() => {
    if (!locomotion || lod.current === 'cull') return
    const loco  = locomotion.current
    const speed = gaitAmount(loco.speed)
    let want = clips.idle
    if (!loco.grounded) want = clips.jump ?? clips.run ?? clips.walk ?? clips.idle
    else if (speed > 1.25) want = clips.run  ?? clips.walk ?? clips.idle
    else if (speed > 0.08) want = clips.walk ?? clips.run  ?? clips.idle

    if (want && want !== current.current) {
      want.reset().play()
      current.current?.crossFadeTo(want, 0.2, false)
      current.current = want
    }
  })

  return (
    <primitive
      object={cloned}
      scale={BASE_BODY.scale}
      position={[0, BASE_BODY.yOffset + groundY * BASE_BODY.scale, 0]}
    />
  )
}
