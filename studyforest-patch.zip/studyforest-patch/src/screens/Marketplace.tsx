import { useState } from 'react'
import { MarketplacePanel } from '../components/marketplace/MarketplacePanel'
import './Marketplace.css'

/**
 * Marketplace screen — full-page wrapper that hosts the MarketplacePanel.
 * Can be used as:
 *   • A full dedicated route  /marketplace
 *   • A modal overlay over the 3D realm (pass onClose to go back)
 *
 * Usage in your router / App.tsx:
 *
 *   import { Marketplace } from './screens/Marketplace'
 *   // as a route:
 *   <Route path="/marketplace" element={<Marketplace />} />
 *   // as an overlay inside RealmScreen:
 *   {showMarketplace && <Marketplace onClose={() => setShowMarketplace(false)} />}
 */
export function Marketplace({ onClose }: { onClose?: () => void }) {
  return (
    <div className="marketplace-screen" role="dialog" aria-modal="true" aria-label="Marketplace">
      {/* Backdrop — click to close if used as overlay */}
      {onClose && (
        <div className="marketplace-backdrop" onClick={onClose} aria-hidden="true" />
      )}
      <div className="marketplace-panel-wrapper">
        <MarketplacePanel onClose={onClose} />
      </div>
    </div>
  )
}
