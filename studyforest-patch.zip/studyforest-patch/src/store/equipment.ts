/**
 * Equipment Store (Zustand)
 *
 * Manages which item is equipped in each slot, equipment presets,
 * and preview mode (try-on without committing).
 *
 * Equipped slots are persisted to both localStorage (instant startup) and the
 * server (cross-device sync via InsForge). Only the 8 equipped item ids are
 * synced over the network — never the full inventory.
 */

import { create } from 'zustand'
import { insforge } from '../lib/insforge'
import type { EquippedItems, EquipmentPreset, EquipSlot } from '../marketplace/types'
import { getCatalogItem, SLOT_FOR_CATEGORY } from '../marketplace/catalog'
import { useInventory } from './inventory'
import type { AvatarConfig } from '../avatar/config'
import { DEFAULT_AVATAR_CONFIG, EQUIP_SLOT_TO_CONFIG_KEY } from '../avatar/config'

const EQUIP_KEY   = 'fl_equipped_v1'
const PRESETS_KEY = 'fl_presets_v1'
const TABLE_EQUIP   = 'user_equipped'
const TABLE_PRESETS = 'user_presets'

// ── Helpers ───────────────────────────────────────────────────────────────────

function loadEquipped(): EquippedItems {
  try { return JSON.parse(localStorage.getItem(EQUIP_KEY) ?? '{}') }
  catch { return {} }
}

function loadPresets(): EquipmentPreset[] {
  try { return JSON.parse(localStorage.getItem(PRESETS_KEY) ?? '[]') }
  catch { return [] }
}

function saveEquipped(e: EquippedItems) {
  localStorage.setItem(EQUIP_KEY, JSON.stringify(e))
}
function savePresets(p: EquipmentPreset[]) {
  localStorage.setItem(PRESETS_KEY, JSON.stringify(p))
}

// Build a live AvatarConfig from the base defaults + equipped overrides
function buildAvatarConfig(equipped: EquippedItems, base: AvatarConfig = DEFAULT_AVATAR_CONFIG): AvatarConfig {
  const cfg = { ...base }
  for (const [slot, itemId] of Object.entries(equipped) as [EquipSlot, string | null][]) {
    const key = EQUIP_SLOT_TO_CONFIG_KEY[slot]
    if (key && key !== 'version' && key !== 'skin' && key !== 'eyeColor' && key !== 'bodyType') {
      // @ts-expect-error dynamic key assignment
      cfg[key] = itemId ?? null
    }
  }
  return cfg
}

// ── State ─────────────────────────────────────────────────────────────────────

interface EquipmentState {
  /** Currently equipped items per slot (persisted) */
  equipped:  EquippedItems
  /** Ephemeral try-on overrides (not persisted) — null = use equipped */
  preview:   EquippedItems
  /** Whether preview mode is active */
  previewing: boolean
  /** Saved presets */
  presets:   EquipmentPreset[]

  /** Live avatar config (equipped + base cosmetics) */
  avatarConfig: (base?: AvatarConfig) => AvatarConfig
  /** Preview avatar config (preview overrides + base) */
  previewConfig: (base?: AvatarConfig) => AvatarConfig

  // ── Equip / Unequip ─────────────────────────────────────────────────────
  equip:    (itemId: string) => Promise<void>
  unequip:  (slot: EquipSlot) => Promise<void>

  // ── Preview (try-on) ────────────────────────────────────────────────────
  tryOn:    (itemId: string) => void
  clearPreview: () => void

  // ── Presets ─────────────────────────────────────────────────────────────
  savePreset:   (name: string) => void
  applyPreset:  (id: string)   => Promise<void>
  deletePreset: (id: string)   => void
  renamePreset: (id: string, name: string) => void

  // ── Server sync ─────────────────────────────────────────────────────────
  loadFromServer:  (userId: string) => Promise<void>
  persistEquipped: () => Promise<void>
  clear: () => void
}

let _userId: string | null = null

export const useEquipment = create<EquipmentState>()((set, get) => ({
  equipped:   loadEquipped(),
  preview:    {},
  previewing: false,
  presets:    loadPresets(),

  // ── Computed configs ──────────────────────────────────────────────────────
  avatarConfig:  (base) => buildAvatarConfig(get().equipped, base),
  previewConfig: (base) => {
    const { equipped, preview } = get()
    const merged = { ...equipped, ...preview }
    return buildAvatarConfig(merged, base)
  },

  // ── Equip ─────────────────────────────────────────────────────────────────
  equip: async (itemId) => {
    const item = getCatalogItem(itemId)
    if (!item) { console.warn(`[Equipment] Unknown item: ${itemId}`); return }

    // Guard: user must own the item
    if (!useInventory.getState().owns(itemId)) {
      console.warn(`[Equipment] Cannot equip unowned item: ${itemId}`)
      return
    }

    set((s) => {
      const next = { ...s.equipped, [item.slot]: itemId }
      saveEquipped(next)
      return { equipped: next, previewing: false, preview: {} }
    })
    await get().persistEquipped()
  },

  // ── Unequip ───────────────────────────────────────────────────────────────
  unequip: async (slot) => {
    set((s) => {
      const next = { ...s.equipped, [slot]: null }
      saveEquipped(next)
      return { equipped: next }
    })
    await get().persistEquipped()
  },

  // ── Preview (try-on without committing) ───────────────────────────────────
  tryOn: (itemId) => {
    const item = getCatalogItem(itemId)
    if (!item) return
    set((s) => ({
      preview:   { ...s.preview, [item.slot]: itemId },
      previewing: true,
    }))
  },

  clearPreview: () => set({ preview: {}, previewing: false }),

  // ── Presets ───────────────────────────────────────────────────────────────
  savePreset: (name) => {
    const preset: EquipmentPreset = {
      id:    `preset_${Date.now()}`,
      name,
      slots: { ...get().equipped },
    }
    set((s) => {
      const next = [...s.presets, preset]
      savePresets(next)
      return { presets: next }
    })
  },

  applyPreset: async (id) => {
    const preset = get().presets.find((p) => p.id === id)
    if (!preset) return
    // Validate: only equip items the user owns
    const inv = useInventory.getState()
    const validated: EquippedItems = {}
    for (const [slot, itemId] of Object.entries(preset.slots) as [EquipSlot, string | null][]) {
      if (itemId == null || inv.owns(itemId)) {
        validated[slot] = itemId ?? null
      }
    }
    set(() => {
      saveEquipped(validated)
      return { equipped: validated, previewing: false, preview: {} }
    })
    await get().persistEquipped()
  },

  deletePreset: (id) => {
    set((s) => {
      const next = s.presets.filter((p) => p.id !== id)
      savePresets(next)
      return { presets: next }
    })
  },

  renamePreset: (id, name) => {
    set((s) => {
      const next = s.presets.map((p) => p.id === id ? { ...p, name } : p)
      savePresets(next)
      return { presets: next }
    })
  },

  // ── Server sync ───────────────────────────────────────────────────────────
  loadFromServer: async (userId) => {
    _userId = userId
    try {
      const { data } = await insforge
        .from(TABLE_EQUIP)
        .select('slot, item_id')
        .eq('user_id', userId)
      if (data) {
        const equipped: EquippedItems = {}
        for (const row of data as Array<Record<string, string>>) {
          equipped[row.slot as EquipSlot] = row.item_id ?? null
        }
        saveEquipped(equipped)
        set({ equipped })
      }
    } catch (err) {
      console.error('[Equipment] loadFromServer failed:', err)
    }

    try {
      const { data } = await insforge
        .from(TABLE_PRESETS)
        .select('id, name, slots')
        .eq('user_id', userId)
      if (data) {
        const presets = (data as Array<Record<string, unknown>>).map((r) => ({
          id:    r.id as string,
          name:  r.name as string,
          slots: r.slots as EquippedItems,
        }))
        savePresets(presets)
        set({ presets })
      }
    } catch (err) {
      console.error('[Equipment] loadFromServer presets failed:', err)
    }
  },

  persistEquipped: async () => {
    if (!_userId) return
    const { equipped } = get()
    try {
      // Upsert each slot individually so partial updates are safe
      const rows = Object.entries(equipped)
        .filter(([, v]) => v !== undefined)
        .map(([slot, itemId]) => ({ slot, item_id: itemId ?? null }))
      if (rows.length > 0) {
        await insforge.from(TABLE_EQUIP).upsert(rows)
      }
    } catch (err) {
      console.error('[Equipment] persistEquipped failed:', err)
    }
  },

  clear: () => {
    localStorage.removeItem(EQUIP_KEY)
    localStorage.removeItem(PRESETS_KEY)
    _userId = null
    set({ equipped: {}, preview: {}, previewing: false, presets: [] })
  },
}))
