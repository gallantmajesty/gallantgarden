/**
 * Persistent Inventory Store (Zustand)
 *
 * Single source of truth for every item a user owns.
 * Guarantees:
 *  • Items never removed unless admin-revoked
 *  • localStorage cache → instant UI, server sync in background
 *  • O(1) owns() lookup via Map regardless of inventory size
 *  • Startup loads ONLY equipped cosmetics; full inventory fetched on demand
 *  • Server upsert on every acquisition → syncs across devices
 */

import { create } from 'zustand'
import { insforge } from '../lib/insforge'
import type { InventoryEntry, ObtainSource } from '../marketplace/types'
import { STARTER_ITEM_IDS, getCatalogItem } from '../marketplace/catalog'

const TABLE     = 'user_inventory'
const CACHE_KEY = 'fl_inventory_v1'

// ── DB row shape ──────────────────────────────────────────────────────────────
// Table: user_inventory
//   user_id     uuid  FK → auth.users   (set server-side via RLS)
//   item_id     text  FK → catalog item id
//   obtained_at timestamptz
//   source      text  ObtainSource
//   UNIQUE (user_id, item_id)

interface InventoryState {
  items:     Map<string, InventoryEntry>
  loaded:    boolean
  syncing:   boolean
  syncError: string | null

  owns:       (itemId: string) => boolean
  getEntry:   (itemId: string) => InventoryEntry | undefined
  ownedList:  () => InventoryEntry[]

  addItem:    (itemId: string, source: ObtainSource) => Promise<void>
  addItems:   (itemIds: string[], source: ObtainSource) => Promise<void>

  loadFromServer:      (userId: string) => Promise<void>
  bootstrapStarterKit: (userId: string) => Promise<void>
  clear: () => void
}

function serialise(items: Map<string, InventoryEntry>): string {
  return JSON.stringify(Array.from(items.values()))
}
function deserialise(raw: string | null): Map<string, InventoryEntry> {
  if (!raw) return new Map()
  try {
    const arr = JSON.parse(raw) as InventoryEntry[]
    return new Map(arr.map((e) => [e.itemId, e]))
  } catch { return new Map() }
}

export const useInventory = create<InventoryState>()((set, get) => ({
  items:     deserialise(localStorage.getItem(CACHE_KEY)),
  loaded:    false,
  syncing:   false,
  syncError: null,

  // ── Queries ───────────────────────────────────────────────────────────────
  owns:      (id) => get().items.has(id),
  getEntry:  (id) => get().items.get(id),
  ownedList: () =>
    Array.from(get().items.values())
      .sort((a, b) => new Date(b.obtainedAt).getTime() - new Date(a.obtainedAt).getTime()),

  // ── Mutations ─────────────────────────────────────────────────────────────
  addItem: async (itemId, source) => {
    if (!getCatalogItem(itemId)) {
      console.warn(`[Inventory] Unknown item: ${itemId}`)
      return
    }
    if (get().items.has(itemId)) return   // idempotent

    const entry: InventoryEntry = { itemId, obtainedAt: new Date().toISOString(), source }

    // Optimistic update first — UI feels instant
    set((s) => {
      const next = new Map(s.items)
      next.set(itemId, entry)
      localStorage.setItem(CACHE_KEY, serialise(next))
      return { items: next }
    })

    // Persist to server (upsert is safe; unique constraint prevents duplicates)
    try {
      await insforge.from(TABLE).upsert({
        item_id: itemId, obtained_at: entry.obtainedAt, source,
      })
    } catch (err) {
      // Don't roll back — item stays locally. Next loadFromServer reconciles.
      console.error('[Inventory] Server persist failed:', err)
    }
  },

  addItems: async (itemIds, source) => {
    await Promise.all(itemIds.map((id) => get().addItem(id, source)))
  },

  // ── Server sync ───────────────────────────────────────────────────────────
  loadFromServer: async (userId) => {
    set({ syncing: true, syncError: null })
    try {
      const { data, error } = await insforge
        .from(TABLE)
        .select('item_id, obtained_at, source')
        .eq('user_id', userId)
      if (error) throw error

      const items = new Map<string, InventoryEntry>()
      for (const row of (data ?? []) as Array<Record<string, string>>) {
        const entry: InventoryEntry = {
          itemId:     row.item_id,
          obtainedAt: row.obtained_at,
          source:     row.source as ObtainSource,
        }
        items.set(entry.itemId, entry)
      }
      localStorage.setItem(CACHE_KEY, serialise(items))
      set({ items, loaded: true, syncing: false })
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      console.error('[Inventory] loadFromServer failed:', msg)
      set({ loaded: true, syncing: false, syncError: msg })
    }
  },

  bootstrapStarterKit: async (_userId) => {
    const missing = STARTER_ITEM_IDS.filter((id) => !get().owns(id))
    if (missing.length > 0) {
      await get().addItems(Array.from(missing), 'starter')
      console.info(`[Inventory] Starter kit: granted ${missing.length} items`)
    }
  },

  clear: () => {
    localStorage.removeItem(CACHE_KEY)
    set({ items: new Map(), loaded: false, syncing: false, syncError: null })
  },
}))
